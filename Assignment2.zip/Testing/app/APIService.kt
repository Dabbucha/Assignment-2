package com.example.assignment2.api

import com.example.assignment2.models.AuthRequest
import com.example.assignment2.models.AuthResponse
import com.example.assignment2.models.DashboardResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {
    @POST("footscray/auth")
    suspend fun authenticate(@Body request: AuthRequest): Response<AuthResponse>

    @GET("dashboard/{keypass}")
    suspend fun getDashboard(@Path("keypass") keypass: String): Response<DashboardResponse>
}
