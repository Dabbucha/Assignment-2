package com.example.assignment2.repository

import com.example.assignment2.api.ApiService
import com.example.assignment2.models.AuthRequest
import com.example.assignment2.models.AuthResponse
import com.example.assignment2.models.DashboardResponse

class UserRepository(private val apiService: ApiService) {

    suspend fun authenticate(username: String, password: String): AuthResponse? {
        val response = apiService.authenticate(AuthRequest(username, password))
        return if (response.isSuccessful) response.body() else null
    }

    suspend fun getDashboard(keypass: String): DashboardResponse? {
        val response = apiService.getDashboard(keypass)
        return if (response.isSuccessful) response.body() else null
    }
}
