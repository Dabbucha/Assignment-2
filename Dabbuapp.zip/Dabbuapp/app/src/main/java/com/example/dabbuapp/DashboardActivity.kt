package com.example.dabbuapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch
import retrofit2.HttpException

class DashboardActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var entityAdapter: EntityAdapter
    private var entities: List<Entity> = listOf()
    private lateinit var keypass: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        keypass = intent.getStringExtra("keypass") ?: ""
        recyclerView = findViewById(R.id.recyclerView)

        recyclerView.layoutManager = LinearLayoutManager(this)
        entityAdapter = EntityAdapter(entities) { entity ->
            val intent = Intent(this, DetailsActivity::class.java)
            intent.putExtra("entity", entity)
            startActivity(intent)
        }
        recyclerView.adapter = entityAdapter

        fetchDashboardData()
    }

    private fun fetchDashboardData() {
        lifecycleScope.launch {
            try {
                val response = RetrofitClient.instance.getDashboard(keypass)
                if (response.isSuccessful) {
                    entities = response.body()?.entities ?: emptyList()
                    entityAdapter.updateEntities(entities)
                } else {
                    Log.e("Dashboard Error", "Error: ${response.message()}")
                }
            } catch (e: HttpException) {
                Log.e("Dashboard Error", "HTTP Exception: ${e.message()}")
            } catch (e: Exception) {
                Log.e("Dashboard Error", "Error: ${e.message}")
            }
        }
    }
}
