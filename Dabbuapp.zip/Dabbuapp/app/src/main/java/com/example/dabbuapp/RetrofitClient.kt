package com.example.dabbuapp

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.Response

// Define your API service interface
interface ApiService {
    @POST("/footscray/auth") // Adjust this endpoint based on your class location
    suspend fun login(@Body loginRequest: LoginRequest): Response<LoginResponse>

    @GET("/dashboard/{keypass}")
    suspend fun getDashboard(@Path("keypass") keypass: String): Response<DashboardResponse>
}

// Create Retrofit client
object RetrofitClient {
    private const val BASE_URL = "https://nit3213-api-h2b3-latest.onrender.com"

    val instance: ApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        retrofit.create(ApiService::class.java)
    }
}
