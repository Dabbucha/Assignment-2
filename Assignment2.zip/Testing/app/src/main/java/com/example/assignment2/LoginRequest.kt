package com.example.assignment2

data class LoginRequest(
    val username: String,
    val password: String
)

