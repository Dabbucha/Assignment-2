package com.example.assignment2.models
data class AuthRequest(
    val username: String,
    val password: String
)

data class AuthResponse(
    val keypass: String
)

data class Entity(
    val property1: String,
    val property2: String,
    val description: String
)

data class DashboardResponse(
    val entities: List<Entity>,
    val entityTotal: Int
)
