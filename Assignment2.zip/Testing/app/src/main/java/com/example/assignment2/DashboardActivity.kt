package com.example.assignment2

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class DashboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_dashboard)

        // Set padding for edge-to-edge display
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Find the camera and microphone ImageView elements
        val cameraImageView = findViewById<ImageView>(R.id.imageView)
        val microphoneImageView = findViewById<ImageView>(R.id.imageView2)

        // Set onClickListeners for the ImageViews
        cameraImageView.setOnClickListener {
            // Start Detail activity when camera image is clicked
            val intent = Intent(this, Detail::class.java)
            startActivity(intent)
        }

        microphoneImageView.setOnClickListener {
            // Start Detail activity when microphone image is clicked
            val intent = Intent(this, Detail::class.java)
            startActivity(intent)
        }
    }
}
