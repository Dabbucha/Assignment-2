package com.example.dabbuapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Response

class LoginActivity : AppCompatActivity() {

    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var errorTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Initialize UI elements
        usernameEditText = findViewById(R.id.usernameEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        loginButton = findViewById(R.id.loginButton)
        errorTextView = findViewById(R.id.errorTextView)

        // Set click listener for the login button
        loginButton.setOnClickListener {
            performLogin()
        }
    }

    private fun performLogin() {
        val username = usernameEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()

        // Create the login request object
        val loginRequest = LoginRequest(username, password)

        // Launch a coroutine for the network request
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Call the suspend function for login
                val response: Response<LoginResponse> = RetrofitClient.instance.login(loginRequest)

                // Switch to the Main thread to update UI
                withContext(Dispatchers.Main) {
                    if (response.isSuccessful) {
                        val keypass = response.body()?.keypass // Access the keypass here
                        if (keypass != null) {
                            // Successful login, navigate to the DashboardActivity
                            val intent = Intent(this@LoginActivity, DashboardActivity::class.java)
                            intent.putExtra("keypass", keypass) // Pass the keypass
                            startActivity(intent)
                            finish() // Close the login activity
                        } else {
                            // Handle failed login
                            errorTextView.text = "Login failed: Invalid credentials"
                            errorTextView.visibility = View.VISIBLE
                        }
                    } else {
                        // Handle response errors
                        errorTextView.text = "Login failed: ${response.message()}"
                        errorTextView.visibility = View.VISIBLE
                    }
                }
            } catch (e: Exception) {
                // Handle any exceptions, such as network errors
                Log.e("LoginActivity", "Login error: ${e.message}")
                withContext(Dispatchers.Main) {
                    errorTextView.text = "Login error: ${e.message}"
                    errorTextView.visibility = View.VISIBLE
                }
            }
        }
    }
}
