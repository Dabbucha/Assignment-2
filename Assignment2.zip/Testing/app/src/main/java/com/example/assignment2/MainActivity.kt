package com.example.assignment2

import android.os.Bundle
import android.content.Intent
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import com.example.assignment2.viewmodel.UserViewModel

class MainActivity : AppCompatActivity() {

    lateinit var usernameInput: EditText
    lateinit var passwordInput: EditText
    lateinit var loginBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI components
        usernameInput = findViewById(R.id.username_input)
        passwordInput = findViewById(R.id.Password_input)
        loginBtn = findViewById(R.id.login_btn)

        // Handle login button click
        loginBtn.setOnClickListener {
            val username = usernameInput.text.toString()
            val password = passwordInput.text.toString()

            // Check if username and password match the required credentials
            if (username == "Dabbu" && password == "s8073286") {
                // Logging the credentials for testing purposes
                Log.i("TestCredentials", "Username: $username, Password: $password")

                // Intent to start DashboardActivity
                val intent = Intent(this, DashboardActivity::class.java)
                startActivity(intent)
            } else {
                // Show error message if credentials are incorrect
                Toast.makeText(this, "Invalid Username or Password", Toast.LENGTH_SHORT).show()
            }
        }
    }




    abstract class MainActivity : AppCompatActivity() {

        private val userViewModel: UserViewModel by usermodels()

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)

            val username = "John"
            val password = "s12345678"

            userViewModel.authResponse.observe(this, Observer { authResponse ->
                authResponse?.let {
                    // Successfully authenticated
                    val keypass = it.keypass
                    userViewModel.getDashboard(keypass)
                }
            })

            userViewModel.dashboardResponse.observe(this, Observer { dashboardResponse ->
                dashboardResponse?.let {
                    // Successfully retrieved dashboard data
                    // Use the data as needed
                    val entities = it.entities
                    val entityTotal = it.entityTotal
                    // Do something with the data
                }
            })

            userViewModel.authenticate(username, password)
        }
    }

}

class UserViewModel {

}

private operator fun Any.getValue(mainActivity: MainActivity.MainActivity, property: KProperty<*>): Any {

}
