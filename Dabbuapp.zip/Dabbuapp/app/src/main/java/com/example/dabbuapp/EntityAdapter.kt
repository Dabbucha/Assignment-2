package com.example.dabbuapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EntityAdapter(private var entities: List<Entity>, private val onClick: (Entity) -> Unit) :
    RecyclerView.Adapter<EntityAdapter.EntityViewHolder>() {

    class EntityViewHolder(itemView: View, private val onClick: (Entity) -> Unit) : RecyclerView.ViewHolder(itemView) {
        private val property1TextView: TextView = itemView.findViewById(R.id.property1TextView)
        private val property2TextView: TextView = itemView.findViewById(R.id.property2TextView)

        fun bind(entity: Entity) {
            property1TextView.text = entity.property1
            property2TextView.text = entity.property2

            itemView.setOnClickListener { onClick(entity) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EntityViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_entity, parent, false)
        return EntityViewHolder(view, onClick)
    }

    override fun onBindViewHolder(holder: EntityViewHolder, position: Int) {
        holder.bind(entities[position])
    }

    override fun getItemCount(): Int {
        return entities.size
    }

    fun updateEntities(newEntities: List<Entity>) {
        entities = newEntities
        notifyDataSetChanged()
    }
}
