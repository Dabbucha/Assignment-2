package com.example.dabbuapp
import java.io.Serializable



data class LoginRequest(
    val username: String, // This will be the user's first name
    val password: String  // This will be the student's ID (e.g., s12345678)
)

data class LoginResponse(
    val keypass: String? // This should match the API response
)


data class Entity(
    val property1: String,
    val property2: String,
    val description: String
) : Serializable

data class DashboardResponse(
    val entities: List<Entity>,
    val entityTotal: Int
)
