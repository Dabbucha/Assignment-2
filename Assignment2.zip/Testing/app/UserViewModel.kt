package com.example.assignment2.viewmodel

import androidx.lifecycle.*
import com.example.assignment2.api.RetrofitClient
import com.example.assignment2.api.ApiService
import com.example.assignment2.models.AuthResponse
import com.example.assignment2.models.DashboardResponse
import com.example.assignment2.repository.UserRepository
import kotlinx.coroutines.launch

class UserViewModel : ViewModel() {
    private val apiService = RetrofitClient.instance.create(ApiService::class.java)
    private val repository = UserRepository(apiService)

    private val _authResponse = MutableLiveData<AuthResponse>()
    val authResponse: LiveData<AuthResponse> get() = _authResponse

    private val _dashboardResponse = MutableLiveData<DashboardResponse>()
    val dashboardResponse: LiveData<DashboardResponse> get() = _dashboardResponse

    fun authenticate(username: String, password: String) {
        viewModelScope.launch {
            val response = repository.authenticate(username, password)
            _authResponse.postValue(response)
        }
    }

    fun getDashboard(keypass: String) {
        viewModelScope.launch {
            val response = repository.getDashboard(keypass)
            _dashboardResponse.postValue(response)
        }
    }
}
