package com.example.assignment2

data class LoginResponse(
    val keypass: String
)
